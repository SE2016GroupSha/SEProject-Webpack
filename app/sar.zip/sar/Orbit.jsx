var ExcelUtils = require('./ExcelUtils.jsx');
var ExcelModle = require('./ExcelModle.jsx');
require('../../resource/css/wxl/wxl.css');

var Orbit = React.createClass( {
 propTypes: {

 },
 getInitialState: function() {
 return {
			msg: [],
			pdos: [],
			datas:[],
			files_data:[],
			files_pdo:[],
			rightstate: 'unknown',
			state_pdo_or_data:'unknown',
 };
 },
 componentDidMount: function() {
		
 },
	handleContinue:function(information){
		if(information=='continue'){
			this.addAllPDO(this.state.pdos);
			
			
		}else{
			this.indexClickHandle(0);
		}
	},
	addAllPDO:function(pdos){

		var httpParams = {'pdos': pdos};
		$.ajax( {
			async: false,//阻塞的，保证刷新得到的视图是新的
			type: "POST",
			cache: false,
			url: "api/pdo/add",
			data: {'params':JSON.stringify(httpParams)},
			success:function(data){
						
			}
		});	
		this.setState({
			msg: [],
			pdos: pdos,
			rightstate:'success',
			state_pdo_or_data:'pdo',
		});
	},
	handleFileDATA:function(e){
		
	},
	handleFilePDO: function(e) {

		var self = this;
		var files = e.target.files;
		var i,f;
		for (i=0,f=files[i]; i!=files.length; ++i) {
			
			var reader = new FileReader();
			var name = f.name;
			reader.onload = function(e) {
	
				var data = e.target.result;
				var status = {'state':'unknown'};
				var pdos = [];
				var errorMsg = [];
			
				ExcelUtils.readPDOFromExcel(data, status, pdos, errorMsg);
				
				for (var i=0; i<errorMsg.length; i++) {
					console.log(errorMsg[i]);
				}
				console.log(pdos);
				console.log(errorMsg.length);
				
				if(errorMsg.length!=0){
					var regx=/格式警告/;
					var flag = true;
					for(var k=0;k<errorMsg.length;k++){
						if(regx.exec(errorMsg[k])== null){
							flag = false;
						}
					}
					if(flag){
						console.log('warning');
						//$("#pdo-add-warning-modal").modal('show');
						self.setState({
							msg: errorMsg,
							pdos: pdos,
							rightstate:'warning',
							state_pdo_or_data:'pdo',
						});
					}else{
						console.log('error');
						self.setState({
							msg: errorMsg,
							pdos: pdos,
							rightstate:'error',
							state_pdo_or_data:'pdo',
						});
						//$("#pdo-add-error-modal").modal('show');
					}
				}else{
					self.addAllPDO(pdos);
					
				}
			};
			reader.readAsBinaryString(f);
		}
		this.setState({
			files_pdo: []
		});
	},
	indexClickHandle :function(n){
		if(n ==0){
			
		}else{
			
		}
	},
 render: function() {
		//a onFocus={this.showClearFocus} href={"#modal-show-" + this.props.id} className="btn" 
			var msgs = [];
			for (var i=0; i<this.state.msg.length; i++) {
				msgs.push(<p key={i}>{this.state.msg[i]}</p>);
			}
			var tables = [];
			for (var i=0; i<this.state.pdos.length; i++) {
				var fields = '';
				for (var j=0; j<this.state.pdos[i]['fields'].length; j++) {
					fields = fields + this.state.pdos[i]['fields'][j] + ' ';
				}
				tables.push(<tr key={i}><td>{this.state.pdos[i]['name']}</td><td>{fields}</td></tr>);
			}
			var rightsideview=[];
			var leftsideview=[];
			if(this.state.state_pdo_or_data == 'unknown'){
				
				rightsideview.push(
					<div key={0} className="fade-in-right-big smooth">
					
						<div className="container w-auto-xs " style={{'width':'700px'}}>
						
						 <div className="text-center m-b-lg">
						 
							<br/>
							<br/>
							<h1 className="new3 text-white">欢迎使用导入工具</h1>
						 </div>
						 <br/><br/>
						 <div className="list-group bg-info auto m-b-sm m-b-lg">
						 
							
							<label className="list-group-item" htmlFor="filestyle-0">
							 <i className="fa fa-chevron-right text-muted"></i>
							 <i className="fa fa-fw fa-mail-forward m-r-xs"></i> 导入模板
							</label>
							<label className="list-group-item" htmlFor="filestyle-0">
							 <i className="fa fa-chevron-right text-muted"></i>
							 <i className="fa fa-fw fa-sign-in m-r-xs"></i> 导入数据
							</label>
							
						 </div>
						 <div className="text-center ">
							<p><small className="text-muted">SE Group SHA &nbsp;&nbsp;© 2016</small></p>
						 </div>
						</div>
					</div>
				);
				
			}else if(this.state.state_pdo_or_data == 'pdo'){
				leftsideview.push(
								<div className="col w-md bg-light dk b-r bg-auto" key={0}>
									<div className="wrapper b-b bg text-center">
										<div className="h4">Excel导入工具</div>
									</div>
									<div className="wrapper hidden-sm hidden-xs"  >
										<ul className="nav nav-pills nav-stacked nav-sm">
											<li><label className="list-group-item  b-l-3x hover-anchor a_active" htmlFor="filestyle-0">导入模板</label></li> 
											<li><label className="list-group-item  b-l-3x hover-anchor a_no_active" htmlFor="filestyle-0">导入数据</label></li> 
										</ul>
									</div>
								 </div>
				);
				rightsideview.push(
									<ExcelModle key={0}
									pdos={this.state.pdos}
									mystate={this.state.rightstate}
									msg={this.state.msg}
									handleContinue={this.handleContinue}
									/>
				);
			}else{
				
			}
		return (
			<div className="app-content">
			 <div className="app-content-body fade-in-up">
				 <div className="hbox hbox-auto-xs hbox-auto-sm">
					<div className="app-content-body app-content-full fade-in-up h-full">
						<div className="hbox hbox-auto-xs bg-light ">
							{/*<!-- 左侧开始 -->*/}
							{leftsideview}
							{/*<!-- 左侧结束 -->*/}
							
						{/*<!-- 右侧 -->*/}
						 <div className="col">
							<div className="vbox">	
							 <div className="row-row">
								<div className="cell">
								{/*右侧内部*/}
								{rightsideview}
								<input value={this.state.files_pdo} type="file" data-icon="false" data-classbutton="btn btn-default" 
							data-classinput="form-control inline v-middle input-s" id="filestyle-0" tabIndex="-1" 
							style={{'position':'absolute','clip':'rect(0px 0px 0px 0px)'}} onChange={this.handleFilePDO}/>
							
							<input value={this.state.files_data} type="file" data-icon="false" data-classbutton="btn btn-default"
							data-classinput="form-control inline v-middle input-s" id="filestyle-1" tabIndex="-1" 
							style={{'position':'absolute','clip':'rect(0px 0px 0px 0px)'}} onChange={this.handleFileDATA}/>
								
								 {/*右侧内部结束*/}
								</div>
							 </div>
							</div>
						 </div>
						 
						</div>
					</div>
				 </div>
			 </div>
			 
		 </div>
		);
 }
});

module.exports = Orbit;