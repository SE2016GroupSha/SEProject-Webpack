var Search = React.createClass( {
    propTypes: {

    },
    getInitialState: function() {
        return {

        };
    },
    componentDidMount: function() {
		
    },
    render: function() {
		return (
			<div className="app-content">
			  <div className="app-content-body fade-in-up">
				  <div className="hbox hbox-auto-xs hbox-auto-sm">
					Search
				  </div>
			  </div>
		    </div>
		);
    }
});

module.exports = Search;